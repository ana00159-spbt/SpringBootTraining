package com.conferencedemo.controller;

import java.util.List;
//import java.util.*;

//import com.conferencedemo.dao.EmployeeDAO;
import com.conferencedemo.model.Employee;
import com.conferencedemo.service.EmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainRESTController {
	
	@Autowired
	private EmployeeService employeeService;
	
	public List<Employee> listEmployees() {
		return employeeService.findAll();
	}

	@RequestMapping("/")
	public String welcome() {
		return "Welcome to RestTemplate Demo.";
	}
	
	@RequestMapping("SpringBoot")
	public String welcome1() {
		return "Welcome to Welcome to Spring Boot Training";
	}

	// URL - Get all employees - http://localhost:8080/employees
	@RequestMapping(value = "/employees", //
			method = RequestMethod.GET, //
			produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Employee> getEmployees() {
		List<Employee> list = employeeService.findAll();
		return list;
	}

	//URL - Update existing employee list - http://localhost:8080/employee
	/*@RequestMapping(value = "/employee",//
			method = RequestMethod.PUT, //
			produces = { MediaType.APPLICATION_JSON_VALUE })
	public Employee updateEmployee(@RequestBody Employee emp) {
		return employeeService.updateEmp(emp);
	}*/
	
	//URL - Insert to existing employee list - http://localhost:8080/employee
	/*@RequestMapping(value = "/employee",//
			method = RequestMethod.POST, //
			produces = { MediaType.APPLICATION_JSON_VALUE })
	public Employee insertEmployee(@RequestBody Employee emp) {
		return employeeService.insertEmp(emp);
	}*/
	
		
    // URL - http://localhost:8080/employee/{empNo}
    @DeleteMapping(value = "/employee/{empNo}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public void deleteEmployee(@PathVariable("empNo") String empNo) {
        employeeService.deleteEmployee(empNo);
       // return "Employee Deleted " + empNo;
       
    }
    
  // URL - PUT http://localhost:8080/employee}
 	@RequestMapping(value = "/employee", method = RequestMethod.PUT, produces = { MediaType.APPLICATION_JSON_VALUE })
 	public Employee updateEmployee(@ModelAttribute Employee employee) {
 		return employeeService.updateEmployee(employee);
 	}
}